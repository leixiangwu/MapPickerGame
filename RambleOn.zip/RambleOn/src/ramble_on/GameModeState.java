/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ramble_on;

/**
 *
 * @author Leixiang
 */
public enum GameModeState {

    SUB_REGION_MODE, FLAG_MODE, LEADER_MODE, CAPITAL_MODE
};
