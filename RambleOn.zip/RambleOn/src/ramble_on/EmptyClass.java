/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ramble_on;

/**
 *
 * @author Leixiang
 */
public class EmptyClass {
    //This class describes the format of my data.
    //Every account has its own text file in data folder and the name of text file is its name.
/*
     Name of Account|Number of Regions that this account has played.
     Name of Region(Format is Continent_Nation)|Number of modes have been played.
     XXXX_Mode|YOUR NUMBER OF TIMES PLAYED|HIGHEST SCORE|FASTEST TIME IN SECONDS
     XXXX_Mode|YOUR NUMBER OF TIMES PLAYED|HIGHEST SCORE|FASTEST TIME IN SECONDS
     Name of Region(Format is Continent_Nation)|Number of modes have been played.
     XXXX_Mode|YOUR NUMBER OF TIMES PLAYED|HIGHEST SCORE|FASTEST TIME IN SECONDS
     */
}
